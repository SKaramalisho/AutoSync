﻿#========================================================================================================================================================================#
#========================================================================================================================================================================#

# AUTHOR                          :                   SAM KARAMALISHO                                                                                                    #
# AUTHOR                          :                   https://github.com/SKaramalisho/Automation                                                                         #
# AUTHOR                          :                   https://www.linkedin.com/in/karamalishosamandar/                                                                   #

#========================================================================================================================================================================#
#========================================================================================================================================================================#

# Version                         :                   1.7                                                                                                                #
# UPDATED                         :                   2023-06-19                                                                                                         #

#========================================================================================================================================================================#
#========================================================================================================================================================================#

# LICENSE                         :                   MIT License                                                                                                        #

# LICENSE                         :                   Copyright (c) 2023 Samandar (Sam) Karamalisho                                                                      #

# LICENSE                         :                   Permission is hereby granted, free of charge, to any person obtaining a copy                                       #
# LICENSE                         :                   of this software and associated documentation files (the "Software"), to deal                                      #
# LICENSE                         :                   in the Software without restriction, including without limitation the rights                                       #
# LICENSE                         :                   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          #
# LICENSE                         :                   copies of the Software, and to permit persons to whom the Software is                                              #
# LICENSE                         :                   furnished to do so, subject to the following conditions:                                                           #

# LICENSE                         :                   The above copyright notice and this permission notice shall be included in all                                     #
# LICENSE                         :                   copies or substantial portions of the Software.                                                                    #

# LICENSE                         :                   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         #
# LICENSE                         :                   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           #
# LICENSE                         :                   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        #
# LICENSE                         :                   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             #
# LICENSE                         :                   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      #
# LICENSE                         :                   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      #
# LICENSE                         :                   SOFTWARE.                                                                                                          #

#========================================================================================================================================================================#
#========================================================================================================================================================================#

param(

[string]$AG,
[string]$Type,
[string]$AGListener,
[string]$Frequency,
[string]$Action

) 

$Target = $AG
$SyncType = $Type
$ConnST = $AGListener
$ExecFrequency = $Frequency

function Get-ClusterAOAGs {
	Get-ClusterResource | where-Object resourcetype -eq "SQL Server Availability Group" | select-object name 
}

IF ([string]::IsNullOrWhiteSpace($Target) -eq 'True') {write-host "
The following AGs have been found, on this cluster:
" -foregroundcolor green
Get-ClusterAOAGs | ft -HideTableHeaders

$Target = read-host 'Please input the target Availability Group''s Name

!!  If the listener does not match the AG name, execute the script with the -AGListener parameter  !!

'}


IF ([string]::IsNullOrWhiteSpace($AGListener) -eq 'True') {$ConnST = $Target}

if ($Action -eq "Install"){

IF ([string]::IsNullOrWhiteSpace($SyncType) -eq 'True') {
$SyncType = read-host '
Select your desired Login Synchronization type: "ALL", "WHITELIST", "BLACKLIST"

ALL - Synchronizes ALL Logins

WHITELIST - Only Synchronizes Logins in the "PrimaryPrincipals_Whitelist" Table
* YOU Are required to maintain this list/table *

BLACKLIST - Synchronizes ALL Logins EXCEPT Logins in the "PrimaryPrincipals_Blacklist" Table
* YOU Are required to maintain this list/table *


'
}

write-host "

Deploying AGPrincipals...

"

$query = "
use master
if not exists (select name from sys.databases where name = 'AGPrincipals_$Target') 
BEGIN
CREATE DATABASE [AGPrincipals_$Target]; 

ALTER DATABASE [AGPrincipals_$Target] SET ALLOW_SNAPSHOT_ISOLATION ON;

BACKUP DATABASE [AGPrincipals_$Target] to DISK ='AGPrincipals_$Target`_AGSEED.FULL.BAK'; 

declare @@SetSeeding table
(
Replica nvarchar(max) not null,
ID int identity not null
)
declare @@RevertSeeding table
(
Replica nvarchar(max) not null,
ID int identity not null
)

insert into @@RevertSeeding
select distinct 'ALTER AVAILABILITY GROUP [$Target] MODIFY REPLICA ON N'''+ar.replica_server_name+''' WITH (SEEDING_MODE = MANUAL)'
from sys.availability_replicas ar 
join sys.availability_groups ag 
on ag.group_id = ar.group_id
where 
ag.name = '$Target'
and ar.seeding_mode_desc = 'MANUAL'


insert into @@SetSeeding
select distinct 'ALTER AVAILABILITY GROUP [$Target] MODIFY REPLICA ON N'''+ar.replica_server_name+''' WITH (SEEDING_MODE = AUTOMATIC)'
from sys.availability_replicas ar 
join sys.availability_groups ag 
on ag.group_id = ar.group_id
where 
ag.name = '$Target'
and ar.seeding_mode_desc = 'MANUAL'


declare @maxID int 
set @maxID = (select MAX(ID) from @@SetSeeding)
declare @ItemID int;
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @SetAutoSeed nvarchar(max);
set @SetAutoSeed = (select replica from @@SetSeeding where ID = @ItemID)

 --Create Logins If NotExists on Secondary or If Login Name Doesn't Match
print @SetAutoSeed
exec sp_executesql @SetAutoSeed

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


ALTER AVAILABILITY GROUP ["+$Target+"] ADD DATABASE [AGPrincipals_$Target]; 

declare @maxIDrev int 
set @maxID = (select MAX(ID) from @@RevertSeeding)
declare @ItemIDrev int;
set @ItemIDrev = 1
while (@ItemIDrev <= @maxIDrev)
begin
begin
/*===========================================================================================================*/

declare @RevertAutoSeed nvarchar(max);
set @RevertAutoSeed = (select replica from @@RevertSeeding where ID = @ItemIDrev)

 --Create Logins If NotExists on Secondary or If Login Name Doesn't Match
print @RevertAutoSeed
exec sp_executesql @RevertAutoSeed

/*============================================================================================================*/
end
set @ItemIDrev  = @ItemIDrev + 1
end

END 
ELSE 
print 'AGPrincipals_$Target already exists' 
"


invoke-sqlcmd -query $query -ServerInstance $ConnST

Start-Sleep -Seconds 5

$SetListTab = "

USE AGPrincipals_$Target;

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals_$SyncType')
BEGIN
CREATE TABLE [dbo].[PrimaryPrincipals_$SyncType](
	[NAME] [nvarchar](128) NOT NULL,
	[EnteredBy] [nvarchar](128) NOT NULL DEFAULT (suser_sname()),
	[EnteredDateTime] [datetime] NOT NULL  DEFAULT (getdate())
) 
END
"

IF ($SyncType -ne "ALL"){invoke-sqlcmd -query $SetListTab -ServerInstance $ConnST}



$ALLQ = "

USE [AGPrincipals_$Target]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_PrimaryWorkload] 
as
BEGIN
SET TRANSACTION ISOLATION LEVEL SNAPSHOT 
/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*==================================================================== Start PrimaryPrincipals Load ==========================================================================*/
DECLARE @db VARCHAR(255)
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryPrincipals from system data
============================================================================================
*/
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
INTO [PrimaryPrincipals]
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipalsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPrincipalsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)


insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)


END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)

insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New login checksums are found
Start loading new logins into PrimaryPrincipals from system data
============================================================================================
*/
insert into [PrimaryPrincipals]
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
and CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryPrincipals])

END
/*===================================================================== End PrimaryPrincipals Load ==========================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN

/*=================================================================== Start PrimaryRoleMembership Load =======================================================================*/
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryRoleMembership from system data
============================================================================================
*/
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
		INTO [PrimaryRoleMembership]
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembershipAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryRoleMembershipAudit]
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
insert into [PrimaryRoleMembershipAudit]
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryRoleMembership from system data
============================================================================================
*/
insert into PrimaryRoleMembership
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
and CHECKSUM(spr.name,spm.name) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryRoleMembership])

END
/*=================================================================== End PrimaryRoleMembership Load =======================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*=================================================================== Start PrimaryPermissions Load ========================================================================*/
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
INTO [PrimaryPermissions]
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
END



IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissionsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPermissionsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
insert into [PrimaryPermissionsAudit]
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END


IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryPermissions from system data
============================================================================================
*/
insert into PrimaryPermissions
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from [PrimaryPermissions])
END



/*=================================================================== End PrimaryPermissions Load ========================================================================*/
END

/* Start CLEANUP */

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)


delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END

/* End CLEANUP */

/*END PROCEDURE LOGIC*/

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_SecondaryWorkload]
AS
BEGIN
/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

declare @@VarCommandTab table
(
CreationScript nvarchar(max) not null,
ID int identity not null
)
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name not like '%\%' and pp.SID not in (select sid from sys.server_principals) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH NAME = ['+pp.name+']' from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.sid = pp.sid
where sp.name not like '%\%' and sp.SID = pp.SID and sp.name != pp.name
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] FROM WINDOWS' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name like '%\%'
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=OFF; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=ON;' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 1
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 0

declare @maxID int 
set @maxID = (select MAX(ID) from @@VarCommandTab)
declare @ItemID int;
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @NonIntrusiveLoginCreationOrNameAdjustment nvarchar(max);
set @NonIntrusiveLoginCreationOrNameAdjustment = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Create Logins If NotExists on Secondary or If Login Name Doesn't Match
print @NonIntrusiveLoginCreationOrNameAdjustment
exec sp_executesql @NonIntrusiveLoginCreationOrNameAdjustment

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end

/* Build TSQL and Execute Intrusive Login Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+pp.name+']; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp on sp.name = pp.name
where sp.name not like '%\%'  and sp.name = pp.name and sp.SID != pp.SID

set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @IntrusiveLoginDropandCreate nvarchar(max);
set @IntrusiveLoginDropandCreate = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
 print @IntrusiveLoginDropandCreate
exec sp_executesql @IntrusiveLoginDropandCreate

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Disable Orphaned Secondary Logins */

delete from @@VarCommandTab
/* This will DROP the login instead of disabling it */
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+sp.name+']' 
from sys.server_principals sp
where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'


/* This will disable the login instead of deleting it */
------select 'ALTER LOGIN ['+sp.name+'] DISABLE' 
------from sys.server_principals sp
------where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
------sp.type in ('S','U','G') and
------sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
------sp.SID != 0x01 and sp.name != 'distributor_admin'
------and sp.is_disabled = 0





set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @DisableOrphanedSecondary nvarchar(max);
set @DisableOrphanedSecondary = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
  print @DisableOrphanedSecondary
exec sp_executesql @DisableOrphanedSecondary

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Build TSQL and Execute Attribute Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 
CASE sp.is_disabled
	   WHEN 1 THEN 'USE [master] ; GRANT CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] ENABLE'
	   ELSE  'USE [master] ; DENY CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] DISABLE'
	   END 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.name = pp.name where sp.name = pp.name and sp.is_disabled != pp.is_disabled
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_locked != LOGINPROPERTY(sp.name, 'IsLocked') and pp.is_locked = 0 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 1
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 0
insert into @@VarCommandTab
select 
'USE [master] ; ALTER SERVER ROLE ['+prm.role+'] ADD MEMBER ['+prm.login+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership prm
where prm.CHKSUM not in (
select
CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id)
insert into @@VarCommandTab
select
'USE [master] ; ALTER SERVER ROLE ['+spr.name+'] DROP MEMBER ['+spm.name+']'
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
and CHECKSUM(spr.name,spm.name) not IN (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership)

	/* Securables */
insert into @@VarCommandTab
select 
'USE [master] ; USE [MASTER] '+servp.state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+servp.permission_name+' TO ['+servp.name+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions servp
--from sys.server_permissions servp
--join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where servp.CHKSUM not in (select CHECKSUM(svp.state_desc,svp.permission_name,serp.name)
from sys.server_permissions svp
join sys.server_principals serp on svp.grantee_principal_id = serp.principal_id)
insert into @@VarCommandTab
select 
'USE [MASTER] '+'REVOKE '+servp.permission_name collate SQL_Latin1_General_CP1_CI_AS+' TO ['+sp.name collate SQL_Latin1_General_CP1_CI_AS+']'
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions)
and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and (select count(chksum) from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions) > 1 


set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @AttributeChange nvarchar(max);
set @AttributeChange = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --MakeLoginAttributeChanges
   print @AttributeChange
exec sp_executesql @AttributeChange

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end
END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddPermission_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; USE [MASTER] '+state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+permission_name+' TO ['+name+']'
from AGPrincipals_$Target.dbo.PrimaryPermissionsAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddRoleMembership_RemovalID]
@RemovalID varchar(25)
AS
BEGIN
/*

MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/


SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; ALTER SERVER ROLE ['+role+'] ADD MEMBER ['+login+']'
from AGPrincipals_$Target.dbo.PrimaryRoleMembershipAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_CreatePrincipal_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = 
(select 
'USE [master] ; 
Create LOGIN ['+name+']'+
CASE when name like '%\%' then ' from WINDOWS '
else 'WITH password= '+master.dbo.fn_varbintohexstr(password_hash)+' HASHED, 
SID=' +master.dbo.fn_varbintohexstr(SID) +',' +
'CHECK_POLICY=' +CASE is_policy_checked  WHEN 1 THEN 'ON' ELSE 'OFF' END + ', 
CHECK_EXPIRATION=OFF'
END
from  AGPrincipals_$Target.dbo.PrimaryPrincipalsAudit  where RemovalID = @RemovalID)

exec sp_executeSQL @execSTMT

END
GO




"


$BLQ = "

USE AGPrincipals_$Target

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_PrimaryWorkload] 
as
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

/*BEGIN PROCEDURE LOGIC*/

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*==================================================================== Start PrimaryPrincipals Load ==========================================================================*/
DECLARE @db VARCHAR(255)
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryPrincipals from system data
============================================================================================
*/
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
INTO [PrimaryPrincipals]
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name not in (select NAME from PrimaryPrincipals_BlackList)
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipalsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPrincipalsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)


insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)


END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)

insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New login checksums are found
Start loading new logins into PrimaryPrincipals from system data
============================================================================================
*/
insert into [PrimaryPrincipals]
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'and
sp.name not in (select NAME from PrimaryPrincipals_BlackList)
and CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryPrincipals])

END
/*===================================================================== End PrimaryPrincipals Load ==========================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN

/*=================================================================== Start PrimaryRoleMembership Load =======================================================================*/
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryRoleMembership from system data
============================================================================================
*/
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
		INTO [PrimaryRoleMembership]
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'and
spm.name not in (select NAME from PrimaryPrincipals_BlackList)
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembershipAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryRoleMembershipAudit]
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
insert into [PrimaryRoleMembershipAudit]
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryRoleMembership from system data
============================================================================================
*/
insert into PrimaryRoleMembership
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'and
spm.name not in (select NAME from PrimaryPrincipals_BlackList)
and CHECKSUM(spr.name,spm.name) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryRoleMembership])

END
/*=================================================================== End PrimaryRoleMembership Load =======================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*=================================================================== Start PrimaryPermissions Load ========================================================================*/
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
INTO [PrimaryPermissions]
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'and
sp.name not in (select NAME from PrimaryPrincipals_BlackList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
END



IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissionsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPermissionsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
insert into [PrimaryPermissionsAudit]
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END


IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryPermissions from system data
============================================================================================
*/
insert into PrimaryPermissions
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name not in (select NAME from PrimaryPrincipals_BlackList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from [PrimaryPermissions])
END



/*=================================================================== End PrimaryPermissions Load ========================================================================*/
END

/* Start CLEANUP */

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name not in (select NAME from PrimaryPrincipals_BlackList)
)


delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin' and
spm.name not in (select NAME from PrimaryPrincipals_BlackList)
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name not in (select NAME from PrimaryPrincipals_BlackList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END

/* End CLEANUP */

/*END PROCEDURE LOGIC*/

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_SecondaryWorkload]
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/


declare @@VarCommandTab table
(
CreationScript nvarchar(max) not null,
ID int identity not null
)
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name not like '%\%' and pp.SID not in (select sid from sys.server_principals) and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH NAME = ['+pp.name+']' from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.sid = pp.sid
where sp.name not like '%\%' and sp.SID = pp.SID and sp.name != pp.name and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] FROM WINDOWS' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name like '%\%' and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=OFF; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=ON;' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 1 and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 0 and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 

declare @maxID int 
set @maxID = (select MAX(ID) from @@VarCommandTab)
declare @ItemID int;
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @NonIntrusiveLoginCreationOrNameAdjustment nvarchar(max);
set @NonIntrusiveLoginCreationOrNameAdjustment = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Create Logins If NotExists on Secondary or If Login Name Doesn't Match
print @NonIntrusiveLoginCreationOrNameAdjustment
exec sp_executesql @NonIntrusiveLoginCreationOrNameAdjustment

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end

/* Build TSQL and Execute Intrusive Login Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+pp.name+']; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp on sp.name = pp.name
where sp.name not like '%\%'  and sp.name = pp.name and sp.SID != pp.SID and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 

set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @IntrusiveLoginDropandCreate nvarchar(max);
set @IntrusiveLoginDropandCreate = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
 print @IntrusiveLoginDropandCreate
exec sp_executesql @IntrusiveLoginDropandCreate

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Disable Orphaned Secondary Logins */

delete from @@VarCommandTab
/* This will DROP the login instead of disabling it */
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+sp.name+']' 
from sys.server_principals sp
where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and sp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 


/* This will disable the login instead of deleting it */
------select 'ALTER LOGIN ['+sp.name+'] DISABLE' 
------from sys.server_principals sp
------where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
------sp.type in ('S','U','G') and
------sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
------sp.SID != 0x01 and sp.name != 'distributor_admin'
------and sp.is_disabled = 0





set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @DisableOrphanedSecondary nvarchar(max);
set @DisableOrphanedSecondary = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
  print @DisableOrphanedSecondary
exec sp_executesql @DisableOrphanedSecondary

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Build TSQL and Execute Attribute Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 
CASE sp.is_disabled
	   WHEN 1 THEN 'USE [master] ; GRANT CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] ENABLE'
	   ELSE  'USE [master] ; DENY CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] DISABLE'
	   END 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.name = pp.name where sp.name = pp.name and sp.is_disabled != pp.is_disabled and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_locked != LOGINPROPERTY(sp.name, 'IsLocked') and pp.is_locked = 0  and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 1 and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 0 and pp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 
'USE [master] ; ALTER SERVER ROLE ['+prm.role+'] ADD MEMBER ['+prm.login+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership prm
where prm.CHKSUM not in (
select
CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id) and prm.login not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER SERVER ROLE ['+spr.name+'] DROP MEMBER ['+spm.name+']'
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
and CHECKSUM(spr.name,spm.name) not IN (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership) and spm.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 

	/* Securables */
insert into @@VarCommandTab
select 
'USE [master] ; USE [MASTER] '+servp.state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+servp.permission_name+' TO ['+servp.name+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions servp
--from sys.server_permissions servp
--join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where servp.CHKSUM not in (select CHECKSUM(svp.state_desc,svp.permission_name,serp.name)
from sys.server_permissions svp
join sys.server_principals serp on svp.grantee_principal_id = serp.principal_id) and servp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 
insert into @@VarCommandTab
select 
'USE [MASTER] '+'REVOKE '+servp.permission_name collate SQL_Latin1_General_CP1_CI_AS+' TO ['+sp.name collate SQL_Latin1_General_CP1_CI_AS+']'
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions)
and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and (select count(chksum) from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions) > 1  and sp.name not in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_BlackList) 


set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @AttributeChange nvarchar(max);
set @AttributeChange = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --MakeLoginAttributeChanges
   print @AttributeChange
exec sp_executesql @AttributeChange

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end
END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddPermission_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; USE [MASTER] '+state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+permission_name+' TO ['+name+']'
from AGPrincipals_$Target.dbo.PrimaryPermissionsAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddRoleMembership_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; ALTER SERVER ROLE ['+role+'] ADD MEMBER ['+login+']'
from AGPrincipals_$Target.dbo.PrimaryRoleMembershipAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_CreatePrincipal_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = 
(select 
'USE [master] ; 
Create LOGIN ['+name+']'+
CASE when name like '%\%' then ' from WINDOWS '
else 'WITH password= '+master.dbo.fn_varbintohexstr(password_hash)+' HASHED, 
SID=' +master.dbo.fn_varbintohexstr(SID) +',' +
'CHECK_POLICY=' +CASE is_policy_checked  WHEN 1 THEN 'ON' ELSE 'OFF' END + ', 
CHECK_EXPIRATION=OFF'
END
from  AGPrincipals_$Target.dbo.PrimaryPrincipalsAudit  where RemovalID = @RemovalID)

exec sp_executeSQL @execSTMT

END
GO




"







$WLQ = "

USE [AGPrincipals_$Target]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_PrimaryWorkload] 
as
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

/*BEGIN PROCEDURE LOGIC*/

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*==================================================================== Start PrimaryPrincipals Load ==========================================================================*/
DECLARE @db VARCHAR(255)
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryPrincipals from system data
============================================================================================
*/
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
INTO [PrimaryPrincipals]
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name in (select NAME from PrimaryPrincipals_WhiteList)
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipalsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPrincipalsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)


insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)


END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Logins exist in PrimaryPrincipals and not in the system
Copy orphaned entries from PrimaryPrincipals into PrimaryPrincipalsAudit 
============================================================================================
*/
insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'
)

insert into [PrimaryPrincipalsAudit]
select
name,
CHKSUM
,SID,is_locked,denylogin,is_disabled,is_policy_checked,password_hash, GETDATE() as RemovalDT
from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New login checksums are found
Start loading new logins into PrimaryPrincipals from system data
============================================================================================
*/
insert into [PrimaryPrincipals]
select
sp.name as NAME,
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
,sp.SID,LOGINPROPERTY(sp.name, 'IsLocked') as is_locked,syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'and
sp.name in (select NAME from PrimaryPrincipals_WhiteList)
and CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryPrincipals])

END
/*===================================================================== End PrimaryPrincipals Load ==========================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN

/*=================================================================== Start PrimaryRoleMembership Load =======================================================================*/
EXEC ('USE ' + @db)
IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table doesn't exist
Create and Load PrimaryRoleMembership from system data
============================================================================================
*/
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
		INTO [PrimaryRoleMembership]
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'and
spm.name  in (select NAME from PrimaryPrincipals_WhiteList)
END

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembershipAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryRoleMembershipAudit]
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryRoleMembership and not in the system
Copy orphaned entries from PrimaryRoleMembership into PrimaryRoleMembershipAudit 
============================================================================================
*/
insert into [PrimaryRoleMembershipAudit]
select
Role,
Login,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryRoleMembership from system data
============================================================================================
*/
insert into PrimaryRoleMembership
select
spr.name as Role
,spm.name as Login
,CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'and
spm.name  in (select NAME from PrimaryPrincipals_WhiteList)
and CHECKSUM(spr.name,spm.name) not in 
(select CHKSUM from [AGPrincipals_$Target].[dbo].[PrimaryRoleMembership])

END
/*=================================================================== End PrimaryRoleMembership Load =======================================================================*/
END

IF (SELECT sys.fn_hadr_is_primary_replica ('AGPrincipals_$Target')) = 1 
BEGIN
/*=================================================================== Start PrimaryPermissions Load ========================================================================*/
SET @db = 'AGPrincipals_$Target'
EXEC ('USE ' + @db)

IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
INTO [PrimaryPermissions]
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin'and
sp.name  in (select NAME from PrimaryPrincipals_WhiteList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
END



IF NOT EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissionsAudit')
BEGIN
/*
============================================================================================
If 
- The Audit table doesn't exist
- Items exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT, IDENTITY(bigint,1,1) AS RemovalID
INTO [PrimaryPermissionsAudit]
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)
END

ELSE

BEGIN
/*
============================================================================================
If 
- The Audit table exists
- Entries exist in PrimaryPermissions and not in the system
Copy orphaned entries from PrimaryPermissions into PrimaryPermissionsAudit 
============================================================================================
*/
insert into [PrimaryPermissionsAudit]
select
state_desc,
permission_name,
name,
CHKSUM,
GETDATE() as RemovalDT
from  AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END


IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN
/*
============================================================================================
If 
- The Table exists
- New Role and Member checksums are found
Start loading new entries into PrimaryPermissions from system data
============================================================================================
*/
insert into PrimaryPermissions
select
servp.state_desc,
servp.permission_name,
sp.name,
CHECKSUM(servp.state_desc,servp.permission_name,sp.name) as CHKSUM
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name  in (select NAME from PrimaryPrincipals_WhiteList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from [PrimaryPermissions])
END



/*=================================================================== End PrimaryPermissions Load ========================================================================*/
END

/* Start CLEANUP */

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPrincipals')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where 
CHKSUM not in (
select
CHECKSUM(sp.SID,LOGINPROPERTY(sp.name, 'IsLocked'),syl.denylogin,sp.is_disabled,sl.is_policy_checked,sl.password_hash) as CHKSUM
from sys.server_principals sp 
left  join sys.sql_logins sl 
on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
where 
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name  in (select NAME from PrimaryPrincipals_WhiteList)
)


delete from AGPrincipals_$Target.dbo.[PrimaryPrincipals]
where CHKSUM in (
select CHKSUM from AGPrincipals_$Target.dbo.[PrimaryPrincipals] pp
join sys.server_principals sp on pp.SID=sp.sid
where pp.name != sp.name and pp.SID=sp.SID
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryRoleMembership')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryRoleMembership]
where 
CHKSUM not in (
select
CHECKSUM(spr.name,spm.name)
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin' and
spm.name  in (select NAME from PrimaryPrincipals_WhiteList)
)

END

IF EXISTS (SELECT object_id  FROM sys.tables WHERE name = 'PrimaryPermissions')
BEGIN

delete from AGPrincipals_$Target.dbo.[PrimaryPermissions]
where 
CHKSUM not in (
select
CHECKSUM(servp.state_desc,servp.permission_name,sp.name)
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and
sp.name  in (select NAME from PrimaryPrincipals_WhiteList) and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
)

END

/* End CLEANUP */

/*END PROCEDURE LOGIC*/

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[AGPrincipals_SecondaryWorkload]
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

declare @@VarCommandTab table
(
CreationScript nvarchar(max) not null,
ID int identity not null
)
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name not like '%\%' and pp.SID not in (select sid from sys.server_principals) and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH NAME = ['+pp.name+']' from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.sid = pp.sid
where sp.name not like '%\%' and sp.SID = pp.SID and sp.name != pp.name and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 'USE [master] ; Create LOGIN ['+pp.name+'] FROM WINDOWS' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
where pp.name not in (select name from sys.server_principals) and pp.name like '%\%' and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=OFF; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED; ALTER LOGIN ['+pp.name+'] WITH CHECK_POLICY=ON;' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 1 and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 'USE [master] ; ALTER LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED' from  AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
join sys.sql_logins sl on sl.sid = pp.sid
where sl.sid=pp.sid and pp.password_hash != sl.password_hash and pp.is_policy_checked = 0 and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 

declare @maxID int 
set @maxID = (select MAX(ID) from @@VarCommandTab)
declare @ItemID int;
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @NonIntrusiveLoginCreationOrNameAdjustment nvarchar(max);
set @NonIntrusiveLoginCreationOrNameAdjustment = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Create Logins If NotExists on Secondary or If Login Name Doesn't Match
print @NonIntrusiveLoginCreationOrNameAdjustment
exec sp_executesql @NonIntrusiveLoginCreationOrNameAdjustment

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end

/* Build TSQL and Execute Intrusive Login Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+pp.name+']; Create LOGIN ['+pp.name+'] WITH password= '+master.dbo.fn_varbintohexstr(pp.password_hash)+' HASHED, SID=' +master.dbo.fn_varbintohexstr(pp.SID)+ ' ' 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp on sp.name = pp.name
where sp.name not like '%\%'  and sp.name = pp.name and sp.SID != pp.SID and pp.name in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 

set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @IntrusiveLoginDropandCreate nvarchar(max);
set @IntrusiveLoginDropandCreate = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
 print @IntrusiveLoginDropandCreate
exec sp_executesql @IntrusiveLoginDropandCreate

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Disable Orphaned Secondary Logins */

delete from @@VarCommandTab
/* This will DROP the login instead of disabling it */
insert into @@VarCommandTab
select 'USE [master] ; DROP LOGIN ['+sp.name+']' 
from sys.server_principals sp
where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and sp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 


/* This will disable the login instead of deleting it */
------select 'ALTER LOGIN ['+sp.name+'] DISABLE' 
------from sys.server_principals sp
------where sp.name not in (select name from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals) and
------sp.type in ('S','U','G') and
------sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
------sp.SID != 0x01 and sp.name != 'distributor_admin'
------and sp.is_disabled = 0





set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @DisableOrphanedSecondary nvarchar(max);
set @DisableOrphanedSecondary = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --Drop and Create Logins where the SID Doesn't Match
  print @DisableOrphanedSecondary
exec sp_executesql @DisableOrphanedSecondary

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end


/* Build TSQL and Execute Attribute Changes */

delete from @@VarCommandTab
insert into @@VarCommandTab
select 
CASE sp.is_disabled
	   WHEN 1 THEN 'USE [master] ; GRANT CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] ENABLE'
	   ELSE  'USE [master] ; DENY CONNECT SQL TO ['+pp.name+'] ; ALTER LOGIN ['+pp.name+'] DISABLE'
	   END 
from sys.server_principals sp
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals pp
on sp.name = pp.name where sp.name = pp.name and sp.is_disabled != pp.is_disabled and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_locked != LOGINPROPERTY(sp.name, 'IsLocked') and pp.is_locked = 0  and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=ON, CHECK_EXPIRATION=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 1 and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER LOGIN ['+sp.name+'] WITH CHECK_POLICY=OFF'
from sys.server_principals sp 
left  join sys.sql_logins sl on sl.sid=sp.sid
join sys.syslogins syl on sp.sid=syl.sid
join AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals  pp on pp.name = sp.name
where sp.type in ('S') and sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and sp.SID != 0x01 and sp.name != 'distributor_admin' and
pp.is_policy_checked != sl.is_policy_checked and pp.is_policy_checked = 0 and pp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 
'USE [master] ; ALTER SERVER ROLE ['+prm.role+'] ADD MEMBER ['+prm.login+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership prm
where prm.CHKSUM not in (
select
CHECKSUM(spr.name,spm.name) as CHKSUM
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id) and prm.login  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select
'USE [master] ; ALTER SERVER ROLE ['+spr.name+'] DROP MEMBER ['+spm.name+']'
FROM sys.server_role_members AS server_role_members
INNER JOIN sys.server_principals AS spr
    ON server_role_members.role_principal_id = spr.principal_id
INNER JOIN sys.server_principals AS spm 
    ON server_role_members.member_principal_id = spm.principal_id
where 
spm.type in ('S','U','G') and
spm.name not like '%##%' and spm.name not like'%NT SERVICE\%' and
spm.SID != 0x01 and spm.name != 'distributor_admin'
and CHECKSUM(spr.name,spm.name) not IN (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryRoleMembership) and spm.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 

	/* Securables */
insert into @@VarCommandTab
select 
'USE [master] ; USE [MASTER] '+servp.state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+servp.permission_name+' TO ['+servp.name+']'
from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions servp
--from sys.server_permissions servp
--join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where servp.CHKSUM not in (select CHECKSUM(svp.state_desc,svp.permission_name,serp.name)
from sys.server_permissions svp
join sys.server_principals serp on svp.grantee_principal_id = serp.principal_id) and servp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 
insert into @@VarCommandTab
select 
'USE [MASTER] '+'REVOKE '+servp.permission_name collate SQL_Latin1_General_CP1_CI_AS+' TO ['+sp.name collate SQL_Latin1_General_CP1_CI_AS+']'
from sys.server_permissions servp
join sys.server_principals sp on servp.grantee_principal_id = sp.principal_id
where CHECKSUM(servp.state_desc,servp.permission_name,sp.name) not in (select CHKSUM from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions)
and
sp.type in ('S','U','G') and
sp.name not like '%##%' and sp.name not like'%NT SERVICE\%' and
sp.SID != 0x01 and sp.name != 'distributor_admin' and servp.permission_name != 'CONNECT SQL' and servp.class_desc = 'SERVER'
and (select count(chksum) from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPermissions) > 1  and sp.name  in (select NAME from AGPrincipals_$Target`_syncsnap.dbo.PrimaryPrincipals_WhiteList) 


set @maxID = (select MAX(ID) from @@VarCommandTab)
set @ItemID = 1
while (@ItemID <= @maxID)
begin
begin
/*===========================================================================================================*/

declare @AttributeChange nvarchar(max);
set @AttributeChange = (select CreationScript from @@VarCommandTab where ID = @ItemID)

 --MakeLoginAttributeChanges
   print @AttributeChange
exec sp_executesql @AttributeChange

/*============================================================================================================*/
end
set @ItemID  = @ItemID + 1
end
END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddPermission_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; USE [MASTER] '+state_desc collate SQL_Latin1_General_CP1_CI_AS+' '+permission_name+' TO ['+name+']'
from AGPrincipals_$Target.dbo.PrimaryPermissionsAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_AddRoleMembership_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = (select 
'USE [master] ; ALTER SERVER ROLE ['+role+'] ADD MEMBER ['+login+']'
from AGPrincipals_$Target.dbo.PrimaryRoleMembershipAudit  where RemovalID = @RemovalID)

--print @execSTMT
exec sp_executeSQL @execSTMT

END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Rollback_CreatePrincipal_RemovalID]
@RemovalID varchar(25)
AS
BEGIN

/*
MIT License

Copyright (c) 2023 Samandar (Sam) Karamalisho

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ""Software""), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

SET TRANSACTION ISOLATION LEVEL SNAPSHOT 

declare @execSTMT nvarchar(4000)
set @execSTMT = 
(select 
'USE [master] ; 
Create LOGIN ['+name+']'+
CASE when name like '%\%' then ' from WINDOWS '
else 'WITH password= '+master.dbo.fn_varbintohexstr(password_hash)+' HASHED, 
SID=' +master.dbo.fn_varbintohexstr(SID) +',' +
'CHECK_POLICY=' +CASE is_policy_checked  WHEN 1 THEN 'ON' ELSE 'OFF' END + ', 
CHECK_EXPIRATION=OFF'
END
from  AGPrincipals_$Target.dbo.PrimaryPrincipalsAudit  where RemovalID = @RemovalID)

exec sp_executeSQL @execSTMT

END
GO




"





Start-Sleep -Seconds 5

if ($SyncType -eq 'BLACKLIST')

{
invoke-sqlcmd -query $BLQ -ServerInstance $ConnST
}

if ($SyncType -eq 'WHITELIST')

{
invoke-sqlcmd -query $WLQ -ServerInstance $ConnST
}

if ($SyncType -eq 'ALL')

{
invoke-sqlcmd -query $ALLQ -ServerInstance $ConnST
}





#Skipping the Sleep
#uncomment This eventually
#Start-Sleep -Seconds 30

function Get-ReplicaInstances {
$instcoll = 
"
select distinct 
ar.replica_server_name AS [secondary]
from sys.availability_replicas ar 
join sys.availability_groups ag 
on ag.group_id = ar.group_id
where 
ag.name = '"+$Target+"' 
"
invoke-sqlcmd -query $instcoll -ServerInstance $ConnST
}

$Secondary=Get-ReplicaInstances


Start-Sleep -Seconds 10

IF ([string]::IsNullOrWhiteSpace($ExecFrequency) -eq 'True') {$ExecFrequency = '10'}

function EnableSecondarySync {
foreach ($secondary in $secondary)
{
$SecondaryInst=$secondary.secondary
$enablejobs = "


USE msdb ;  
GO  

declare @saLogin nvarchar(255)
set @saLogin =  (select name from sys.server_principals where SID = 0x01)

EXEC dbo.sp_add_job  
    @job_name = N'!AOAG Sync Logins - $Target',   
    @enabled = 0,  
    @description = N'Updates AGPrincipals_$Target on the Primary Replica. 
	Updates Login attributes on the Secondary Replicas.',  
    @owner_login_name = @saLogin,  
    @notify_level_eventlog = 2;  

GO  

EXEC sp_add_jobstep
    @job_name = N'!AOAG Sync Logins - $Target',
    @step_name = N'ExecuteLoginSync',
    @subsystem = N'TSQL',
   @command = N'USE [master]; set nocount on

IF (SELECT sys.fn_hadr_is_primary_replica (''AGPrincipals_$Target'')) = 1 
BEGIN

declare @PrimaryWorkload nvarchar(2000)
set @PrimaryWorkload = ''USE [AGPrincipals_$Target]; exec AGPrincipals_$Target.dbo.AGPrincipals_PrimaryWorkload;''
IF EXISTS (select 1 from sys.databases where name = ''AGPrincipals_$Target'')
BEGIN
exec sp_executesql @PrimaryWorkload
END

END

IF (SELECT sys.fn_hadr_is_primary_replica (''AGPrincipals_$Target'')) != 1
BEGIN

declare @SnapPreClean nvarchar(2000)
set @SnapPreClean = ''Drop database [AGPrincipals_$Target`_syncsnap]''
IF EXISTS (select * from sys.databases where name like ''%AGPrincipals_$Target`_syncsnap%'')
BEGIN
exec sp_executeSQL @SnapPreClean
END

/* Create Snapshot */
declare @SSPath nvarchar(4000)
set @SSPath = (Select CONVERT(varchar(4000), SERVERPROPERTY(''InstanceDefaultBackupPath''))) + ''\AGPrincipals_$Target`_syncsnap.ss''
declare @SnapCreate nvarchar(2000)

set @SnapCreate = ''
create database [AGPrincipals_$Target`_syncsnap]
ON (
NAME = AGPrincipals_$Target,
FILENAME = ''''''+@SSPath+'''''')
AS SNAPSHOT of AGPrincipals_$Target
''

IF NOT EXISTS (select 1 from sys.databases where name = ''AGPrincipals_$Target`_syncsnap'')
BEGIN
exec sp_executeSQL @SnapCreate
END

declare @SecondaryWorkload nvarchar(2000)
set @SecondaryWorkload = ''USE [AGPrincipals_$Target`_syncsnap]; exec AGPrincipals_$Target`_syncsnap.dbo.AGPrincipals_Secondaryworkload;''
IF EXISTS (select * from sys.databases where name = ''AGPrincipals_$Target`_syncsnap'')
BEGIN
exec sp_executesql @SecondaryWorkload
END

declare @SnapPostClean nvarchar(2000)
set @SnapPostClean = ''Drop database [AGPrincipals_$Target`_syncsnap]''
IF EXISTS (select * from sys.databases where name like ''%AGPrincipals_$Target`_syncsnap%'')
BEGIN
exec sp_executeSQL @SnapPostClean
END

END',
    @retry_attempts = 5,
    @retry_interval = 1 ;
GO
  
EXEC dbo.sp_add_schedule  
    @schedule_name = N'AOAGSync - $Target',  
    @freq_type = 4, 
	@freq_interval = 1, 
	@freq_subday_type = 0x2, 
	@freq_subday_interval = $ExecFrequency,
	@active_start_date = NULL,
    @active_start_time = NULL;  
  
GO 

EXEC sp_attach_schedule  
   @job_name = '!AOAG Sync Logins - $Target',  
   @schedule_name = N'AOAGSync - $Target' ;  
GO  

USE msdb ;  
GO  
  
EXEC dbo.sp_add_jobserver  
    @job_name = N'!AOAG Sync Logins - $Target' ;  
GO  



declare @BorWList nvarchar(255)
set @BorWList = '$SyncType'

IF @BorWList = 'ALL'
BEGIN 
USE msdb
EXEC dbo.sp_update_job  
    @job_name = N'!AOAG Sync Logins - $Target',   
	@enabled = 1 
END " 
invoke-sqlcmd -query $enablejobs -ServerInstance $SecondaryInst
}}
EnableSecondarySync

if ($SyncType -eq 'BLACKLIST') {

write-host "
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



UPDATE [PrimaryPrincipals_BlackList] with your list of EXCLUDED Logins
After updating the list, enable the Sync Job on all secondary Replicas: !AOAG Sync Logins - $Target
(You can re-run this script with the option -Enable, to enable associated sync jobs, on the target AG replicas)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
"

}

if ($SyncType -eq 'WHITELIST') {

write-host "
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



UPDATE [PrimaryPrincipals_WhiteList] with your list of INCLUDED Logins
After updating the list, enable the Sync Job on all secondary Replicas: !AOAG Sync Logins - $Target
(You can re-run this script with the option -Enable, to enable associated sync jobs, on the target AG replicas)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
"

}


if ($SyncType -eq 'ALL') {
write-host "
================================================================================================================
================================================================================================================




!!! Deployment Complete... !!!




================================================================================================================
================================================================================================================
"}
}

if ($Action -eq "Uninstall")
{


write-host "

Removing AGPrincipals...

"

$query = "
use master
if exists (select name from sys.databases where name = 'AGPrincipals_$Target') 
BEGIN
ALTER AVAILABILITY GROUP ["+$Target+"] REMOVE DATABASE [AGPrincipals_$Target]; 
DROP DATABASE [AGPrincipals_$Target]; 
END 
ELSE 
print 'AGPrincipals_$Target does not exists' 
"

invoke-sqlcmd -query $query -ServerInstance $Target

Start-Sleep -Seconds 10

write-host "

Removing AGPrincipals Objects...

"

write-host "
Identifying Replicas for AGPrincipals...
"

function Clean-ReplicaInstances {
$instcoll = 
"
select distinct 
ar.replica_server_name AS [secondary]
from sys.availability_replicas ar 
join sys.availability_groups ag 
on ag.group_id = ar.group_id
where 
ag.name = '"+$Target+"' 
"
invoke-sqlcmd -query $instcoll -ServerInstance $Target
}

$Secondary = Clean-ReplicaInstances


function Remove-Jobs {
foreach ($secondary in $secondary)
{
$SecondaryInst=$secondary.secondary
$removeJob = "
USE msdb ;  
GO
IF EXISTS (SELECT job_id 
            FROM msdb.dbo.sysjobs_view 
            WHERE name = N'!AOAG Sync Logins - $Target')  
EXEC sp_delete_job  
    @job_name = N'!AOAG Sync Logins - $Target' ;  
GO  


declare @SchedID bigint
set @SchedID = (select top 1 schedule_id from msdb.dbo.sysschedules where name = 'AOAGSync - $Target')

if @SchedID is not null
BEGIN
EXEC msdb.dbo.sp_delete_schedule @schedule_id=@SchedID
END


"

invoke-sqlcmd -query $removeJob -ServerInstance $SecondaryInst

}}

write-host "
Removing Jobs...
"

Remove-Jobs

Start-Sleep -Seconds 10

function DropSecondaryDBs {
foreach ($secondary in $secondary)
{
$SecondaryInst=$secondary.secondary
$rmDB = "
use master
if exists (select name from sys.databases where name = 'AGPrincipals_$Target') 
BEGIN
DROP DATABASE [AGPrincipals_$Target]; 
END 
ELSE 
print 'AGPrincipals_$Target does not exists' 
"
invoke-sqlcmd -query $rmDB -ServerInstance $SecondaryInst
}}
DropSecondaryDBs

Start-Sleep -Seconds 10

write-host "
================================================================================================================
================================================================================================================




!!! Removal Complete... !!!




================================================================================================================
================================================================================================================
"

}

if ($Action -eq "Enable")
{

function Get-ReplicaInstances {
$instcoll = 
"
select distinct 
ar.replica_server_name AS [secondary]
from sys.availability_replicas ar 
join sys.availability_groups ag 
on ag.group_id = ar.group_id
where 
ag.name = '"+$Target+"' 
"
invoke-sqlcmd -query $instcoll -ServerInstance $ConnST
}

$Secondary=Get-ReplicaInstances


$EnablePrimaryFirst = "

USE msdb;
IF EXISTS (select 1 from msdb.dbo.sysjobs where name = '!AOAG Sync Logins - $Target')
BEGIN
EXEC dbo.sp_update_job  
    @job_name = N'!AOAG Sync Logins - $Target',   
	@enabled = 1
END 

"

IF ($SyncType -ne "ALL"){invoke-sqlcmd -query $EnablePrimaryFirst -ServerInstance $ConnST}


Start-Sleep -Seconds 5


function EnableSyncJobs {
foreach ($secondary in $secondary)
{
$SecondaryInst=$secondary.secondary
$enablejobs = "

USE msdb;
IF EXISTS (select 1 from msdb.dbo.sysjobs where name = '!AOAG Sync Logins - $Target')
BEGIN
EXEC dbo.sp_update_job  
    @job_name = N'!AOAG Sync Logins - $Target',   
	@enabled = 1
END 
" 
invoke-sqlcmd -query $enablejobs -ServerInstance $SecondaryInst
}}

EnableSyncJobs


write-host "
================================================================================================================
================================================================================================================




!!! Deployment Complete... !!!




================================================================================================================
================================================================================================================
"}
